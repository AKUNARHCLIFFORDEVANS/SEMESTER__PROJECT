#include <iostream>
using namespace std;

float calculateCGPA(int numSemesters,float totalCredits[],float totalGradePoints[]){
	float totalCreditsSum =0;
	float totalGradePointsSum =0;
	 
for (int i=0; i<numSemesters; i++){
	totalCreditsSum +=totalCredits[i];
	totalGradePointsSum +=totalCredits[i]*totalGradePoints[i];
}
return totalGradePointsSum/totalCreditsSum;
}

int main(){
int numSemesters;

cout<<"Enter number of semesters:";
cin>>numSemesters;
	
float totalCredits[numSemesters];
float totalGradePoints[numSemesters];

for (int i=0; i<numSemesters; i++){
cout<<"Enter total credits for semester"<<i+1<<":";
cin>>totalCredits[i];

cout<<"Enter total grade points for semester"<<i+1<<":";
cin>>totalGradePoints[i];	
}	
	
float cgpa = calculateCGPA(numSemesters,totalCredits,totalGradePoints);

cout<<"CGPA:"<<cgpa<<endl;

return 0;	
	
}








